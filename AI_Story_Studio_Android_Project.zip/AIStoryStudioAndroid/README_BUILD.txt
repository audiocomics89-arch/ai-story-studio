AI STORY STUDIO — ANDROID WRAPPER PROJECT

This is an Android Studio project that packages the standalone AI Story Studio web app in a WebView.
It is NOT a compiled APK yet.

BUILD APK:
1. On a computer, install Android Studio (stable) and Android SDK Platform 35.
2. Extract this ZIP.
3. In Android Studio choose File > Open and select the extracted AIStoryStudioAndroid folder.
4. Wait for Gradle sync to finish.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio creates:
   app/build/outputs/apk/debug/app-debug.apk
7. Transfer that APK to your Android phone, open it, and allow installation from that source if Android asks.

The debug APK is suitable for personal testing. A Play Store release needs a release signing key.

APP LIMITATIONS:
- This packages the v1 web app, not a new AI video-generation model.
- Storyboard, image uploads, narration preview and WebM rendering are browser/WebView features.
- Actual AI-generated video scenes still require an external model/API or a GPU server.
- No paid API or API key is included.
